SETUP GUIDE

1. Install MySQL and create database using database.sql
2. Download MySQL Connector/J
3. Add mysql-connector-j.jar to project libraries
4. Open project in VS Code or IntelliJ
5. Run Main.java

Project Structure:
EmployeeManagementSystem/
    src/
        DBConnection.java
        Employee.java
        EmployeeDAO.java
        Main.java
    database.sql
