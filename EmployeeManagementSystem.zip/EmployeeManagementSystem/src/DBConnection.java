import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
	static final String URL = "jdbc:mysql://localhost:3306/employee_db";
	static final String USER ="root";
	static final String PASSWORD ="taher@123";
	
	public static Connection getConnection() {
		Connection con =null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection(URL,USER,PASSWORD);
			System.out.println("Database Connected");
		}catch (Exception e) {
			System.out.println(e); 
			}
		return con;
	}
}