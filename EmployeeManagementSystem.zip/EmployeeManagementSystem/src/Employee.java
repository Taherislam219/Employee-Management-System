public class Employee {

    int id;
    String name;
    String department;
    double salary;
    String phone;

   
    public Employee(int id, String name, String department, double salary, String phone) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
        this.phone = phone;
    }

   
    public Employee(String name, String department, double salary, String phone) {
        this.name = name;
        this.department = department;
        this.salary = salary;
        this.phone = phone;
    }
}