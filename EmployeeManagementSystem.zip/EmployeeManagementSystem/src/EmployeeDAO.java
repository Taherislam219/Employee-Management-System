import java.sql.*;
import java.util.Scanner;

public class EmployeeDAO {

	 static Connection con = DBConnection.getConnection();
	 
	 public boolean authenticate(){
		
	try {
		Scanner sc =new Scanner(System.in);
		
		System.out.print("Username :");
		String Username =sc.nextLine();
		
		System.out.print("Password :");
		String Password =sc.nextLine();
		
		String query ="SELECT * FROM admin WHERE Username=? AND password=?";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1,  Username);
		ps.setString(2, Password);
		
		ResultSet rs =ps.executeQuery();
		
		return rs.next();
		
		
	}catch(Exception e) {
		 System.out.println("Login Error: " + e.getMessage());
		 return false;
	}
		
	}

    public void addEmployee(Employee emp) {

        try {

        	String query = "INSERT INTO employees(name, department, salary, phone) VALUES (?, ?, ?, ?)";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, emp.name);
            pst.setString(2, emp.department);
            pst.setDouble(3, emp.salary);
            pst.setString(4, emp.phone);

            pst.executeUpdate();

            System.out.println("Employee Added Successfully");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void findEmployee(int id) {

        try {

            String query = "SELECT * FROM employees WHERE id=?";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, id);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Department: " + rs.getString("department"));
                System.out.println("Salary: " + rs.getDouble("salary"));
                System.out.println("Phone: " + rs.getString("phone"));

            } else {
                System.out.println("Employee Not Found");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void deleteEmployee(int id) {

        try {

            String query = "DELETE FROM employees WHERE id=?";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setInt(1, id);

            int rows = pst.executeUpdate();

            if (rows > 0) {
                System.out.println("Employee Deleted");
            } else {
                System.out.println("Employee Not Found");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void showAllEmployees() {

        try {

            String query = "SELECT * FROM employees";

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {

                System.out.println("----------------------");
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Department: " + rs.getString("department"));
                System.out.println("Salary: " + rs.getDouble("salary"));
                System.out.println("Phone: " + rs.getString("phone"));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateEmployee(int id, int choice, String value) {

        try {

            String query = "";

            switch (choice) {

                case 1:
                    query = "UPDATE employees SET name=? WHERE id=?";
                    break;

                case 2:
                    query = "UPDATE employees SET department=? WHERE id=?";
                    break;

                case 3:
                    query = "UPDATE employees SET salary=? WHERE id=?";
                    break;

                case 4:
                    query = "UPDATE employees SET phone=? WHERE id=?";
                    break;

                default:
                    System.out.println("Invalid Choice");
                    return;
            }

            PreparedStatement pst = con.prepareStatement(query);

            if (choice == 3) {
                pst.setDouble(1, Double.parseDouble(value));
            } else {
                pst.setString(1, value);
            }

            pst.setInt(2, id);

            int rows = pst.executeUpdate();

            if (rows > 0) {
                System.out.println("Employee Updated Successfully");
            } else {
                System.out.println("Employee Not Found");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
