import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	EmployeeDAO dao = new EmployeeDAO();
        if (!dao.authenticate()) {
            System.out.println("Access Denied!");
            return;
        }

        Scanner sc = new Scanner(System.in);
        

        while (true) {
            System.out.println("\n===== Employee Management System =====");
            System.out.println("1. Add Employee");
            System.out.println("2. Find Employee");
            System.out.println("3. Delete Employee");
            System.out.println("4. Show All Employees");
            System.out.println("5. Update Employee");
            System.out.println("6. Exit");

            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Department: ");
                    String dept = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = sc.nextDouble();
                    System.out.print("Enter Phone: ");
                    String phone = sc.next();
                    Employee emp = new Employee(name, dept, salary, phone);
                    dao.addEmployee(emp);
                    break;
                case 2:
                    System.out.print("Enter Employee ID: ");
                    int findId = sc.nextInt();
                    dao.findEmployee(findId);
                    break;
                case 3:
                    System.out.print("Enter Employee ID: ");
                    int deleteId = sc.nextInt();
                    dao.deleteEmployee(deleteId);
                    break;
                case 4:
                    dao.showAllEmployees();
                    break;
                case 5:
                    System.out.print("Enter Employee ID: ");
                    int updateId = sc.nextInt();
                    System.out.println("What do you want to update?");
                    System.out.println("1. Name");
                    System.out.println("2. Department");
                    System.out.println("3. Salary");
                    System.out.println("4. Phone");
                    System.out.print("Enter Choice: ");
                    int updateChoice = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Value: ");
                    String newValue = sc.nextLine();
                    dao.updateEmployee(updateId, updateChoice, newValue);
                    break;
                case 6:
                    System.out.println("Program Ended");
                    System.exit(0);
                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}
