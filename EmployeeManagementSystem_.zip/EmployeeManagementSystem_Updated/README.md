# Employee Management System (Java + JDBC + MySQL)

A beginner-friendly, console-based employee management project. An admin can add, find, delete, list, and update employee records.

## Features

- Admin login
- Add employee (name, department, salary, phone)
- Find employee by ID
- Delete employee by ID
- Show all employees
- Update employee details
- Prepared SQL statements and automatic JDBC resource closing
- Basic input validation

## Project structure

```text
EmployeeManagementSystem/
├── database.sql
├── README.md
└── src/
    ├── DBConnection.java
    ├── Employee.java
    ├── EmployeeDAO.java
    └── Main.java
```

## Requirements

- JDK 17 or newer (the menu uses modern switch syntax)
- MySQL Server
- MySQL Connector/J added to the Java project's classpath

## Database setup

1. Open MySQL Workbench.
2. Open `database.sql` and run it.
3. If `employee_db` already exists, `CREATE TABLE IF NOT EXISTS` will not change its existing table. If `phone` is missing, run this once:

   ```sql
   USE employee_db;
   ALTER TABLE employees ADD COLUMN phone VARCHAR(20);
   ```

   Only run the `ALTER TABLE` command if the column does not already exist.

The SQL script creates a demo account: username `admin`, password `1234`. Change or remove that account before using real employee information.

## Configure the database connection

`DBConnection.java` reads credentials from environment variables rather than storing the database password in source code:

- `EMPLOYEE_DB_USER` — your MySQL username
- `EMPLOYEE_DB_PASSWORD` — your MySQL password

Set these variables in your operating system or your IDE's run configuration. Do not commit actual passwords to GitHub.

## Run in Eclipse

1. Create/open a Java project.
2. Copy the four `.java` files into the source folder.
3. Add MySQL Connector/J to the project's build path.
4. Set `EMPLOYEE_DB_USER` and `EMPLOYEE_DB_PASSWORD` in the run configuration.
5. Run `Main.java`.

## Security notes

This is a learning/demo project, not production-ready software. The example admin login compares plaintext passwords and the SQL script includes a weak demo password. For real use, implement salted password hashing, remove the default account, add authorization controls, and use a restricted MySQL account instead of a database superuser.

If a real database password was ever committed to GitHub, rotate it. Editing the latest file does not remove it from earlier Git history.
