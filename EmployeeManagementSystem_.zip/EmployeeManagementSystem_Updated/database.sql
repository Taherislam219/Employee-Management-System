-- Employee Management System database schema
-- Run this in MySQL Workbench or your MySQL client.
-- For an existing database, inspect the table first; IF NOT EXISTS does not
-- add missing columns to existing tables.

CREATE DATABASE IF NOT EXISTS employee_db;
USE employee_db;

CREATE TABLE IF NOT EXISTS employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    phone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS admin (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL
);

-- Demo-only initial account. Change this password before using real data.
-- This project still uses plaintext password comparison for coursework/demo.
INSERT INTO admin (username, password)
VALUES ('admin', '1234')
ON DUPLICATE KEY UPDATE username = VALUES(username);
