import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Creates connections to the local employee_db database.
 * Set EMPLOYEE_DB_USER and EMPLOYEE_DB_PASSWORD in your environment.
 */
public class DBConnection {
    private static final String URL =
            "jdbc:mysql://localhost:3306/employee_db?serverTimezone=UTC";
    private static final String USER = System.getenv("EMPLOYEE_DB_USER");
    private static final String PASSWORD = System.getenv("EMPLOYEE_DB_PASSWORD");

    private DBConnection() {
        // Utility class; do not create instances.
    }

    public static Connection getConnection() throws SQLException {
        if (USER == null || USER.isBlank() ||
                PASSWORD == null || PASSWORD.isBlank()) {
            throw new SQLException(
                    "Database credentials are missing. Set EMPLOYEE_DB_USER " +
                    "and EMPLOYEE_DB_PASSWORD before starting the application."
            );
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
