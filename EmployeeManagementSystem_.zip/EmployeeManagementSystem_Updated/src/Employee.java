public class Employee {
    private int id;
    private String name;
    private String department;
    private double salary;
    private String phone;

    public Employee(int id, String name, String department,
                    double salary, String phone) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
        this.phone = phone;
    }

    public Employee(String name, String department,
                    double salary, String phone) {
        this(0, name, department, salary, phone);
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }
    public String getPhone() { return phone; }

    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setDepartment(String department) { this.department = department; }
    public void setSalary(double salary) { this.salary = salary; }
    public void setPhone(String phone) { this.phone = phone; }
}
