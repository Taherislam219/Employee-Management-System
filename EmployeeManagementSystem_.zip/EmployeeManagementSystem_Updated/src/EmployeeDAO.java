import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Database operations for employees and the demo admin login.
 * For a real deployment, replace the demo plaintext admin authentication
 * with a salted password-hashing implementation and proper user management.
 */
public class EmployeeDAO {
    private final Scanner scanner;

    public EmployeeDAO(Scanner scanner) {
        this.scanner = scanner;
    }

    public boolean authenticate() {
        System.out.println("=== Admin Login ===");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        String sql = "SELECT password FROM admin WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    boolean ok = rs.getString("password").equals(password);
                    if (!ok) {
                        System.out.println("Invalid username or password.");
                    }
                    return ok;
                }
            }
            System.out.println("Invalid username or password.");
        } catch (SQLException e) {
            System.out.println("Login/database error: " + e.getMessage());
        }
        return false;
    }

    public boolean addEmployee(Employee employee) {
        String sql = "INSERT INTO employees (name, department, salary, phone) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getDepartment());
            ps.setDouble(3, employee.getSalary());
            ps.setString(4, employee.getPhone());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("Could not add employee: " + e.getMessage());
            return false;
        }
    }

    public Employee findEmployee(int id) {
        String sql = "SELECT id, name, department, salary, phone FROM employees WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapEmployee(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Could not find employee: " + e.getMessage());
        }
        return null;
    }

    public boolean deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("Could not delete employee: " + e.getMessage());
            return false;
        }
    }

    public boolean updateEmployee(Employee employee) {
        String sql = "UPDATE employees SET name = ?, department = ?, salary = ?, phone = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getDepartment());
            ps.setDouble(3, employee.getSalary());
            ps.setString(4, employee.getPhone());
            ps.setInt(5, employee.getId());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("Could not update employee: " + e.getMessage());
            return false;
        }
    }

    public List<Employee> showAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT id, name, department, salary, phone FROM employees ORDER BY id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                employees.add(mapEmployee(rs));
            }
        } catch (SQLException e) {
            System.out.println("Could not load employees: " + e.getMessage());
        }
        return employees;
    }

    private Employee mapEmployee(ResultSet rs) throws SQLException {
        return new Employee(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("department"),
                rs.getDouble("salary"),
                rs.getString("phone")
        );
    }
}
