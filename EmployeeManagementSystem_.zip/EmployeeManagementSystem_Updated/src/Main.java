import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        EmployeeDAO dao = new EmployeeDAO(scanner);

        System.out.println("Employee Management System");
        if (!dao.authenticate()) {
            System.out.println("Login failed or database unavailable. Exiting.");
            return;
        }

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1 -> addEmployee(dao);
                case 2 -> findEmployee(dao);
                case 3 -> deleteEmployee(dao);
                case 4 -> showAllEmployees(dao);
                case 5 -> updateEmployee(dao);
                case 6 -> {
                    running = false;
                    System.out.println("Goodbye!");
                }
                default -> System.out.println("Please choose a number from 1 to 6.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n1. Add Employee");
        System.out.println("2. Find Employee");
        System.out.println("3. Delete Employee");
        System.out.println("4. Show All Employees");
        System.out.println("5. Update Employee");
        System.out.println("6. Exit");
    }

    private static void addEmployee(EmployeeDAO dao) {
        String name = readRequired("Name: ");
        String department = readRequired("Department: ");
        double salary = readDouble("Salary: ");
        String phone = readOptional("Phone: ");
        Employee employee = new Employee(name, department, salary, phone);
        System.out.println(dao.addEmployee(employee) ? "Employee added." : "Employee was not added.");
    }

    private static void findEmployee(EmployeeDAO dao) {
        int id = readInt("Employee ID: ");
        Employee e = dao.findEmployee(id);
        if (e == null) {
            System.out.println("Employee not found (or database unavailable).");
        } else {
            printEmployee(e);
        }
    }

    private static void deleteEmployee(EmployeeDAO dao) {
        int id = readInt("Employee ID to delete: ");
        System.out.println(dao.deleteEmployee(id) ? "Employee deleted." : "Employee was not deleted.");
    }

    private static void showAllEmployees(EmployeeDAO dao) {
        List<Employee> employees = dao.showAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("No employees found, or the database is unavailable.");
            return;
        }
        for (Employee e : employees) {
            printEmployee(e);
        }
    }

    private static void updateEmployee(EmployeeDAO dao) {
        int id = readInt("Employee ID to update: ");
        Employee old = dao.findEmployee(id);
        if (old == null) {
            System.out.println("Employee not found.");
            return;
        }
        System.out.println("Enter the new details:");
        String name = readRequired("Name: ");
        String department = readRequired("Department: ");
        double salary = readDouble("Salary: ");
        String phone = readOptional("Phone: ");
        Employee updated = new Employee(id, name, department, salary, phone);
        System.out.println(dao.updateEmployee(updated) ? "Employee updated." : "Employee was not updated.");
    }

    private static void printEmployee(Employee e) {
        System.out.printf("ID: %d | Name: %s | Department: %s | Salary: %.2f | Phone: %s%n",
                e.getId(), e.getName(), e.getDepartment(), e.getSalary(),
                e.getPhone() == null ? "" : e.getPhone());
    }

    private static String readRequired(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static String readOptional(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = Double.parseDouble(scanner.nextLine().trim());
                if (Double.isFinite(value) && value >= 0) return value;
            } catch (NumberFormatException ignored) {
                // Show the same friendly validation message below.
            }
            System.out.println("Please enter a valid non-negative salary.");
        }
    }
}
